//
//  Constants.swift
//  UpStocks
//
//  Created by Mohit on 05/11/24.
//

import Foundation


// MARK: Api URL's
struct APIURL {
    static let getHoldingList = "https://35dee773a9ec441e9f38d5fc249406ce.api.mockbin.io/"
}

// MARK: App static strings
struct AppStrings {
    static let profitnLoss = "Profit & Loss"
    static let positions = "POSITIONS"
    static let holdings = "HOLDINGS"
    static let portfolio = "Portfolio"
    static let ltp = "LTP"
    static let netQty = "NET QTY"
    static let pnl = "P&L"
    static let somethingWrong = "Something went wrong"
    static let currentValue = "Current Value"
    static let totalInvestment = "Total Investment"
    static let todaysPnl = "Today's Profit & Loss"
    static let watchList = "WatchList"
    static let orders = "Orders"
    static let funds = "Funds"
    static let invest = "Invest"
}
