//
//  CustomTabbarController.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//
import UIKit

class CustomTabBarController: UITabBarController {
    private let indicatorHeight: CGFloat = 3
    private let indicatorView = UIView()

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupIndicator()
        updateIndicatorPosition(at: 2, animated: false)
    }

    private func setupIndicator() {
        if indicatorView.superview == nil {
            indicatorView.backgroundColor = .systemBlue
            tabBar.addSubview(indicatorView)
            tabBar.sendSubviewToBack(indicatorView)
        }

        if let items = tabBar.items, items.count > 0 {
            let tabWidth = tabBar.frame.width / CGFloat(items.count)
            indicatorView.frame = CGRect(x: CGFloat(selectedIndex) * tabWidth, y: 0, width: tabWidth, height: indicatorHeight)
        }
    }

    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        guard let items = tabBar.items, let index = items.firstIndex(of: item) else { return }
        updateIndicatorPosition(at: index, animated: true)
    }

    private func updateIndicatorPosition(at index: Int, animated: Bool) {
        guard let items = tabBar.items, items.count > 0 else { return }
        let tabWidth = tabBar.frame.width / CGFloat(items.count)
        let newX = tabWidth * CGFloat(index)

        if animated {
            UIView.animate(withDuration: 0.3) {
                self.indicatorView.frame.origin.x = newX
            }
        } else {
            indicatorView.frame.origin.x = newX
        }
    }
}
