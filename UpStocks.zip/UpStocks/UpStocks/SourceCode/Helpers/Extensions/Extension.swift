//
//  Extension+UILabel.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import Foundation
import UIKit


extension SceneDelegate: UITabBarControllerDelegate {
    
    // MARK: TabBar Contollers
    func createTabBarController() -> UITabBarController {
        let tabBarController = CustomTabBarController()
        
        let firstVC = createNavController(for: UserPortfolioViewController(), title: AppStrings.watchList, imageName: "house")
        let secondVC = createNavController(for: UserPortfolioViewController(), title: AppStrings.orders, imageName: "magnifyingglass")
        let thirdVC = createNavController(for: UserPortfolioViewController(), title: AppStrings.portfolio, imageName: "heart")
        let fourthVC = createNavController(for: UserPortfolioViewController(), title: AppStrings.funds, imageName: "person")
        let fifthVC = createNavController(for: UserPortfolioViewController(), title: AppStrings.invest, imageName: "gear")
        
        tabBarController.viewControllers = [firstVC, secondVC, thirdVC, fourthVC, fifthVC]
        tabBarController.selectedIndex = 2
        
        if #available(iOS 13.0, *) {
            let appearance = UITabBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = .lightGray
            appearance.stackedLayoutAppearance.selected.iconColor = .systemBlue
            appearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor.systemBlue]
            appearance.stackedLayoutAppearance.normal.iconColor = .gray
            appearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.gray]
            
            tabBarController.tabBar.standardAppearance = appearance
            if #available(iOS 15.0, *) {
                tabBarController.tabBar.scrollEdgeAppearance = appearance
            }
        }
        return tabBarController
    }
    
    private func createNavController(for rootViewController: UIViewController, title: String, imageName: String) -> UINavigationController {
        let navController = UINavigationController(rootViewController: rootViewController)
        navController.tabBarItem.title = title
        navController.tabBarItem.selectedImage = UIImage(systemName: imageName)
        navController.tabBarItem.image = UIImage(systemName: imageName)
        return navController
    }

}

extension NSMutableAttributedString {
    func attributedString(_ value:String, color:UIColor = .red,font:UIFont) -> NSMutableAttributedString {
        
        let attributes:[NSAttributedString.Key : Any] = [
            .font : font,
            .foregroundColor :color
        ]
        self.append(NSAttributedString(string: value, attributes:attributes))
        return self
    }
}
extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        if #available(iOS 11, *) {
            self.clipsToBounds = true
            self.layer.cornerRadius = radius
            var masked = CACornerMask()
            if corners.contains(.topLeft) { masked.insert(.layerMinXMinYCorner) }
            if corners.contains(.topRight) { masked.insert(.layerMaxXMinYCorner) }
            if corners.contains(.bottomLeft) { masked.insert(.layerMinXMaxYCorner) }
            if corners.contains(.bottomRight) { masked.insert(.layerMaxXMaxYCorner) }
            self.layer.maskedCorners = masked
        }
        else {
            let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            let mask = CAShapeLayer()
            mask.path = path.cgPath
            layer.mask = mask
        }
    }
    
    
    func applyShadow( color: UIColor = .black,opacity: Float = 0.25, offset: CGSize = CGSize(width: 0, height: 2), radius: CGFloat = 6) {
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOpacity = opacity
        self.layer.shadowOffset = offset
        self.layer.shadowRadius = radius
        self.layer.masksToBounds = false
    }
}

extension UIViewController {
    private var activityIndicator: UIActivityIndicatorView {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.color = .white
        indicator.center = self.view.center
        indicator.hidesWhenStopped = true
        return indicator
    }
    
    func showLoader() {
        let loader = activityIndicator
        self.view.addSubview(loader)
        loader.startAnimating()
        self.view.isUserInteractionEnabled = false
    }

    func hideLoader() {
        for subview in self.view.subviews {
            if let loader = subview as? UIActivityIndicatorView {
                loader.stopAnimating()
                loader.removeFromSuperview()
            }
        }
        self.view.isUserInteractionEnabled = true
    }
}
extension Double {
    func rounded(toPlaces places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
    
    var formattedWithCommas: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: self)) ?? ""
    }
}

extension UILabel {
    func setTextWithAsterisk(_ text: String, asteriskColor: UIColor = .black.withAlphaComponent(0.6)) {
        let attributedString = NSMutableAttributedString(string: text)
        
        let asterisk = NSAttributedString(
            string: "*",
            attributes: [
                .foregroundColor: asteriskColor,
                .font: UIFont.systemFont(ofSize: self.font.pointSize * 0.9),
                .baselineOffset: self.font.pointSize * 0.2
            ]
        )
        
        attributedString.append(asterisk)
        self.attributedText = attributedString
    }
}
