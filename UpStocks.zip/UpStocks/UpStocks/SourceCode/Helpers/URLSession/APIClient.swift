//
//  APIClient.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import Foundation

class APIClient {
    static let shared = APIClient()
    private init() {}
    
    func fetchData(from urlString: String, completion: @escaping (Result<PortfolioDataModel, Error>) -> Void) {
        guard let url = URL(string: urlString) else {
            completion(.failure(URLError(.badURL)))
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(URLError(.badServerResponse)))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(PortfolioDataModel.self, from: data)
                completion(.success(result))
            } catch {
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
}
