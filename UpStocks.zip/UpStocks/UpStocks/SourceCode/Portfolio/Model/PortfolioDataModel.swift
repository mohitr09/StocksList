//
//  PortfolioDataModel.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import Foundation
struct PortfolioDataModel:Codable {
    var data:Holdings
}
struct Holdings: Codable {
    var userHoldings: [UserHoldings]?
    var currentValue: Double?
    var totalInvestment: Double?
    var todaysPNL: Double?
    var pnl: Double?
    enum CodingKeys: String, CodingKey {
        case userHoldings = "userHolding"
    }
}
struct UserHoldings:Codable {
    let symbol:String
    let quantity:Int
    let ltp: Double
    let avgPrice: Double
    let close: Double
    var pnl: Double?
}

struct HoldingTotalSumModel {
    let title: String
    let value: Double
}
