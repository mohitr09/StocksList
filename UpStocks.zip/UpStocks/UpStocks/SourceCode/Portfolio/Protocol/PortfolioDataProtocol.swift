//
//  PortfolioDataProtocol.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import Foundation

protocol PortfolioDataProtocol: AnyObject {
    func reloadData()
    func success()
    func failure(with message: String)
}

enum HoldingSumTypes: CaseIterable {
    case currentValue
    case totalInvestment
    case todaysPNL
    
    var titleValue: String {
        switch self {
        case .currentValue:
            return AppStrings.currentValue
        case .totalInvestment:
            return AppStrings.totalInvestment
        case .todaysPNL:
            return AppStrings.todaysPnl
        }
    }
}
