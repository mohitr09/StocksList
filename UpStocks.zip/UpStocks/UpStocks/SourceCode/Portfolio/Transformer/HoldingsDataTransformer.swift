//
//  HoldingsDataTransformer.swift
//  UpStocks
//
//  Created by Mohit on 05/11/24.
//

import Foundation

class HoldingsDataTransformer {
    static func transformData( _ data: inout Holdings) -> Holdings {
        
        var currentVal: Double = 0.0
        var totalInvestment: Double = 0.0
        var todaysPNL: Double = 0.0
        var pnl: Double = 0.0
        var userHoldings : [UserHoldings] = []
        
        if let detailHoldings = data.userHoldings {
            for (index,detail) in detailHoldings.enumerated() {
                let perStockcurrentVal = detail.ltp * CGFloat(detail.quantity)
                let perStocktotalInvestment = detail.avgPrice * CGFloat(detail.quantity)
                let perStocktotalPNL = (perStockcurrentVal - perStocktotalInvestment)
                let perStocktodaysPNL = ((detail.close - detail.ltp) * CGFloat(detail.quantity))
                
                userHoldings.append(detail)
                userHoldings[index].pnl = perStocktotalPNL.rounded(toPlaces: 2)
                
                currentVal += perStockcurrentVal
                totalInvestment += perStocktotalInvestment
                todaysPNL += perStocktodaysPNL
                pnl += perStocktotalPNL
                
            }
        }
        data.userHoldings = userHoldings
        data.currentValue = currentVal.rounded(toPlaces: 2)
        data.totalInvestment = totalInvestment.rounded(toPlaces: 2)
        data.todaysPNL = todaysPNL.rounded(toPlaces: 2)
        data.pnl = pnl.rounded(toPlaces: 2)
        return data
    }
}


