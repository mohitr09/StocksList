//
//  UserPortfolioViewController.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import UIKit
import Combine

class UserPortfolioViewController: UIViewController {
    
    //    MARK: Variables
    lazy var headerView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.masksToBounds = true
        view.backgroundColor = UIColor(red: 0/255, green: 50/255, blue: 100/255, alpha: 1.0)
        return view
    }()
    
    lazy var profileButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(named: "profile"), for: .normal)
        button.addTarget(self, action: #selector(profileBtnTapped), for: .touchUpInside)
        return button
    }()
    
    lazy var portfolioLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = .white
        label.text = AppStrings.portfolio
        label.font = .systemFont(ofSize: 16)
        return label
    }()
    
    lazy var searchButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(named: "search"), for: .normal)
        button.addTarget(self, action: #selector(searchBtnTapped), for: .touchUpInside)
        return button
    }()
    
    lazy var filterButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(named: "filter")?.withRenderingMode(.alwaysTemplate), for: .normal)
        button.tintColor = .white
        button.addTarget(self, action: #selector(filterBtnTapped), for: .touchUpInside)
        return button
    }()
    
    lazy var verticalSepratorView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.masksToBounds = true
        view.backgroundColor = .lightGray
        return view
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .singleLine
        tableView.delegate = self
        tableView.dataSource = self
        tableView.showsHorizontalScrollIndicator = false
        tableView.showsVerticalScrollIndicator = false
        tableView.register(PortfolioListTableViewCell.self, forCellReuseIdentifier: PortfolioListTableViewCell.identifier())
        return tableView
    }()
    
    lazy var bottomView: UIView = {
        let view = UIView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor(red: 213/255, green: 213/255, blue: 213/255, alpha: 1.0)
        view.roundCorners(corners: [.topLeft, .topRight], radius: 6.0)
        view.layer.borderWidth = 1.0
        view.applyShadow()
        view.layer.borderColor = UIColor.white.withAlphaComponent(0.1).cgColor
        let tap = UITapGestureRecognizer(target: self, action: #selector(bottomViewTapped(_:)))
        view.addGestureRecognizer(tap)
        
        return view
    }()
    
    lazy var pnlTableView: UITableView = {
        let tableView = UITableView(frame: .zero)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isHidden = true
        tableView.isUserInteractionEnabled = false
        tableView.register(PNLFieldsTableViewCell.self, forCellReuseIdentifier: PNLFieldsTableViewCell.identifier())
        return tableView
    }()
    
    lazy var pnlLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = .black.withAlphaComponent(0.7)
        label.font = .systemFont(ofSize: 12.0)
        label.setTextWithAsterisk(AppStrings.profitnLoss)
        return label
    }()
    
    lazy var pnlValue: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = .red
        label.font = .systemFont(ofSize: 12.0)
        return label
    }()
    
    lazy var arrowImage: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "up_arrow")
        return imageView
    }()
    
    lazy var positionButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.setTitle(AppStrings.positions, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 12)
        button.addTarget(self, action: #selector(portfolioTypeSelected(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var holdingsButton: UIButton = {
        let button = UIButton(frame: .zero)
        button.setTitle(AppStrings.holdings, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.black, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 12)
        button.addTarget(self, action: #selector(portfolioTypeSelected(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var stackView: UIStackView = {
        let view = UIStackView(frame: .zero)
        view.axis = .horizontal
        view.distribution = .fillEqually
        view.alignment = .center
        view.spacing = 0
        view.addArrangedSubview(positionButton)
        view.addArrangedSubview(holdingsButton)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var sepratorView: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black.withAlphaComponent(0.3)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var pnlSepratorView: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black.withAlphaComponent(0.3)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()

    lazy var underLineView: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black.withAlphaComponent(0.8)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var viewModel = PortfolioViewModel(with: self)
    private var cancellables = Set<AnyCancellable>()
    private let bottomViewHeight = 40.0
    
    //    MARK: View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white

        self.showLoader()
        self.viewModel.getHoldingDataList()
    }
    
    //    MARK: Setup view constraints
    private func setupViews() {
        self.view.addSubview(self.headerView)
        self.headerView.topAnchor.constraint(equalTo: self.view.topAnchor).isActive = true
        self.headerView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.headerView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.headerView.heightAnchor.constraint(equalToConstant: 84.0).isActive = true
        self.view.layoutIfNeeded()
        
        self.headerView.addSubview(profileButton)
        self.profileButton.leadingAnchor.constraint(equalTo: self.headerView.leadingAnchor, constant: 10.0).isActive = true
        self.profileButton.heightAnchor.constraint(equalToConstant: 24).isActive = true
        self.profileButton.widthAnchor.constraint(equalToConstant: 24).isActive = true
        self.profileButton.bottomAnchor.constraint(equalTo: self.headerView.bottomAnchor, constant: -8).isActive = true
        self.headerView.layoutIfNeeded()
        
        self.headerView.addSubview(portfolioLabel)
        self.portfolioLabel.centerYAnchor.constraint(equalTo: self.profileButton.centerYAnchor).isActive = true
        self.portfolioLabel.leadingAnchor.constraint(equalTo: self.profileButton.trailingAnchor, constant: 14).isActive = true
        self.headerView.layoutIfNeeded()
        
        self.headerView.addSubview(searchButton)
        self.searchButton.centerYAnchor.constraint(equalTo: self.profileButton.centerYAnchor).isActive = true
        self.searchButton.trailingAnchor.constraint(equalTo: self.headerView.trailingAnchor, constant: -10).isActive = true
        self.searchButton.heightAnchor.constraint(equalToConstant: 24).isActive = true
        self.searchButton.widthAnchor.constraint(equalToConstant: 24).isActive = true
        self.headerView.layoutIfNeeded()
        
        self.headerView.addSubview(verticalSepratorView)
        self.verticalSepratorView.centerYAnchor.constraint(equalTo: self.searchButton.centerYAnchor).isActive = true
        self.verticalSepratorView.heightAnchor.constraint(equalToConstant: 24).isActive = true
        self.verticalSepratorView.widthAnchor.constraint(equalToConstant: 1).isActive = true
        self.verticalSepratorView.trailingAnchor.constraint(equalTo: self.searchButton.leadingAnchor, constant: -10).isActive = true
        self.headerView.layoutIfNeeded()
        
        self.headerView.addSubview(filterButton)
        self.filterButton.centerYAnchor.constraint(equalTo: self.profileButton.centerYAnchor).isActive = true
        self.filterButton.trailingAnchor.constraint(equalTo: self.verticalSepratorView.leadingAnchor, constant: -10).isActive = true
        self.filterButton.heightAnchor.constraint(equalToConstant: 24).isActive = true
        self.filterButton.widthAnchor.constraint(equalToConstant: 24).isActive = true
        self.headerView.layoutIfNeeded()
        
        self.view.addSubview(stackView)
        self.stackView.topAnchor.constraint(equalTo: self.headerView.bottomAnchor).isActive = true
        self.stackView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.stackView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.stackView.heightAnchor.constraint(equalToConstant: 38).isActive = true
        self.view.layoutIfNeeded()
        
        self.view.addSubview(sepratorView)
        self.sepratorView.topAnchor.constraint(equalTo: self.stackView.bottomAnchor, constant: 0).isActive = true
        self.sepratorView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.sepratorView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.sepratorView.heightAnchor.constraint(equalToConstant: 1).isActive = true
        self.view.layoutIfNeeded()
        
        let tabBarHeight = self.tabBarController?.tabBar.frame.height ?? 84
        
        self.view.addSubview(tableView)
        self.tableView.topAnchor.constraint(equalTo: self.sepratorView.bottomAnchor, constant: 8).isActive = true
        self.tableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.tableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.tableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -(tabBarHeight + bottomViewHeight)).isActive = true
        self.view.layoutIfNeeded()
        
        self.view.addSubview(bottomView)
        self.bottomView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -tabBarHeight).isActive = true
        self.bottomView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        self.bottomView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        self.bottomView.heightAnchor.constraint(equalToConstant: bottomViewHeight).isActive = true
        self.tableView.layoutIfNeeded()
        
        self.bottomView.addSubview(pnlLabel)
        self.pnlLabel.bottomAnchor.constraint(equalTo: self.bottomView.bottomAnchor, constant: -10).isActive = true
        self.pnlLabel.leadingAnchor.constraint(equalTo: self.bottomView.leadingAnchor, constant: 16).isActive = true
        self.bottomView.layoutIfNeeded()
        
        self.bottomView.addSubview(arrowImage)
        self.arrowImage.centerYAnchor.constraint(equalTo: self.pnlLabel.centerYAnchor).isActive = true
        self.arrowImage.heightAnchor.constraint(equalToConstant: 10).isActive = true
        self.arrowImage.widthAnchor.constraint(equalToConstant: 10).isActive = true
        self.arrowImage.leadingAnchor.constraint(equalTo: self.pnlLabel.trailingAnchor, constant: 12).isActive = true
        self.bottomView.layoutIfNeeded()
        
        self.bottomView.addSubview(pnlValue)
        self.pnlValue.centerYAnchor.constraint(equalTo: self.pnlLabel.centerYAnchor).isActive = true
        self.pnlValue.trailingAnchor.constraint(equalTo: self.bottomView.trailingAnchor, constant: -16).isActive = true
        self.bottomView.layoutIfNeeded()
        
        self.bottomView.addSubview(pnlSepratorView)
        self.pnlSepratorView.bottomAnchor.constraint(equalTo: self.pnlLabel.topAnchor, constant: -10).isActive = true
        self.pnlSepratorView.heightAnchor.constraint(equalToConstant: 1).isActive = true
        self.pnlSepratorView.leadingAnchor.constraint(equalTo: self.pnlLabel.leadingAnchor).isActive = true
        self.pnlSepratorView.trailingAnchor.constraint(equalTo: self.pnlValue.trailingAnchor).isActive = true
        self.bottomView.layoutIfNeeded()
        
        self.bottomView.addSubview(pnlTableView)
        self.pnlTableView.topAnchor.constraint(equalTo: self.bottomView.topAnchor, constant: 10).isActive = true
        self.pnlTableView.bottomAnchor.constraint(equalTo: self.pnlSepratorView.topAnchor, constant: 10).isActive = true
        self.pnlTableView.leadingAnchor.constraint(equalTo: self.bottomView.leadingAnchor).isActive = true
        self.pnlTableView.trailingAnchor.constraint(equalTo: self.bottomView.trailingAnchor).isActive = true
        self.bottomView.layoutIfNeeded()
        
        if let pnlValue = (self.viewModel.holdingDetails?.pnl ) {
            if pnlValue > 0 {
                self.pnlValue.attributedText = NSMutableAttributedString().attributedString("₹\(pnlValue.formattedWithCommas)", color: .black, font: .systemFont(ofSize: 12))
            }else {
                self.pnlValue.attributedText = NSMutableAttributedString().attributedString("-₹\((abs(pnlValue).formattedWithCommas))", color: .red, font: .systemFont(ofSize: 12))
            }
        }
        
        self.viewModel.$isExpanded.sink { [weak self] isExpanded in
            self?.updateUI(for: isExpanded)
        }.store(in: &cancellables)
        
        self.view.addSubview(underLineView)
        self.updateButtonView(selectedButton: self.holdingsButton)
        
    }
    
    private func updateUI(for isExpanded: Bool) {
        self.arrowImage.image = isExpanded ? UIImage(named: "down_arrow") : UIImage(named: "up_arrow")
        self.bottomView.constraints.filter({$0.firstAnchor == bottomView.heightAnchor }).forEach{ $0.isActive = false }
        self.pnlTableView.isHidden = !isExpanded
        self.pnlSepratorView.isHidden = !isExpanded
        if isExpanded {
            let perRowHeight = self.pnlTableView.cellForRow(at: IndexPath(row: 0, section: 0))?.frame.height ?? 44
            self.bottomView.heightAnchor.constraint(equalToConstant: (perRowHeight * CGFloat(self.viewModel.totalCalculationModel?.count ?? 0)) + bottomViewHeight).isActive = true
        }else {
            self.bottomView.heightAnchor.constraint(equalToConstant: bottomViewHeight).isActive = true
        }
    }
    
    private func updateButtonView(selectedButton: UIButton) {
        guard let title = selectedButton.title(for: .normal) else { return }
           
           let titleSize = (title as NSString).size(withAttributes: [
               .font: selectedButton.titleLabel?.font ?? UIFont.systemFont(ofSize: 14)
           ])
        let underlineHeight: CGFloat = 2
        UIView.animate(withDuration: 0.3) {
            self.underLineView.frame = CGRect(x: selectedButton.frame.origin.x + (selectedButton.frame.width - titleSize.width) / 2, y: self.stackView.frame.maxY - 8, width: titleSize.width , height: underlineHeight)
        }
    }
    
    //    MARK: Actions
    @objc func profileBtnTapped() {}
    @objc func searchBtnTapped() {}
    @objc func filterBtnTapped() {}
    @objc private func bottomViewTapped(_ sender: UITapGestureRecognizer) {
        viewModel.toggleExpandCollapse()
    }
    
    @objc func portfolioTypeSelected(_ sender: UIButton) {
        self.updateButtonView(selectedButton: sender)
    }
    
}
//    MARK: TableView extension
extension UserPortfolioViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch tableView {
        case pnlTableView:
            return self.viewModel.totalCalculationModel?.count ?? 0
        default:
            return self.viewModel.holdingDetails?.userHoldings?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch tableView {
        case pnlTableView:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: PNLFieldsTableViewCell.identifier()) as? PNLFieldsTableViewCell else {
                return UITableViewCell()
            }
            if let totalValue = self.viewModel.totalCalculationModel?[indexPath.row] {
                cell.detail = totalValue
            }
            return cell
        default:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: PortfolioListTableViewCell.identifier()) as? PortfolioListTableViewCell else {
                return UITableViewCell()
            }
            if let holding = self.viewModel.holdingDetails?.userHoldings?[indexPath.row] {
                cell.stockDetail = holding
            }
            return cell
        }
        
    }
}
extension UserPortfolioViewController: PortfolioDataProtocol {
    func reloadData() {
        self.tableView.reloadData()
    }
    
    func success() {
        self.hideLoader()
        self.setupViews()
        self.tableView.reloadData()
    }
    
    func failure(with message: String) {
        self.hideLoader()
        print(message)
    }
}
