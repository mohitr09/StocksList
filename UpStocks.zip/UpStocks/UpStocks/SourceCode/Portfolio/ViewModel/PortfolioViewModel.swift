//
//  PortfolioViewModel.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import Foundation

class PortfolioViewModel: ObservableObject {
    
    @Published var isExpanded: Bool = false
    weak var delegate: PortfolioDataProtocol?
    var holdingDetails: Holdings?
    var totalCalculationModel: [HoldingTotalSumModel]?
    init(with delegate: PortfolioDataProtocol) {
        self.delegate = delegate
    }
    
    func toggleExpandCollapse() {
        isExpanded.toggle()
    }
    
    func getHoldingDataList() {
        let url = APIURL.getHoldingList
        APIClient.shared.fetchData(from: url, completion: { result in
            switch result {
            case .success(var response):
                let transformData = HoldingsDataTransformer.transformData(&response.data)
                self.addHoldingSumCalculations(data: transformData)
                self.holdingDetails = transformData
                DispatchQueue.main.async {
                    self.delegate?.success()
                }
            case .failure( _):
                DispatchQueue.main.async {
                    self.delegate?.failure(with: AppStrings.somethingWrong)
                }
            }
        })
    }
    
    func addHoldingSumCalculations(data: Holdings) {
        self.totalCalculationModel = []
        for val in HoldingSumTypes.allCases {
            switch val {
            case .currentValue:
                self.totalCalculationModel?.append(HoldingTotalSumModel(title: val.titleValue, value: data.currentValue ?? 0.0))
            case .totalInvestment:
                self.totalCalculationModel?.append(HoldingTotalSumModel(title: val.titleValue, value: data.totalInvestment ?? 0.0))
            case .todaysPNL:
                self.totalCalculationModel?.append(HoldingTotalSumModel(title: val.titleValue, value: data.todaysPNL ?? 0.0))
            }
        }
    }
}
