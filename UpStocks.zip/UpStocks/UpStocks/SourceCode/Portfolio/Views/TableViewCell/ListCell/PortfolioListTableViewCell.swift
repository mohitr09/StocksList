//
//  PortfolioListTableViewCell.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import UIKit

class PortfolioListTableViewCell: UITableViewCell {

    
//    MARK: Variables
    lazy var stockNameLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .boldSystemFont(ofSize: 14)
        label.textColor = .black
        return label
    }()
    
    lazy var stockLTPLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var stockQtyLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var stockPNLLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var stockDetail: UserHoldings? {
        didSet {
            if let stockDetail = self.stockDetail {
                self.stockNameLabel.text = stockDetail.symbol
                self.stockLTPLabel.attributedText = NSMutableAttributedString().attributedString("\(AppStrings.ltp): ", color: .lightGray, font: .systemFont(ofSize: 12)).attributedString("₹\(stockDetail.ltp.formattedWithCommas)", color: .black, font: .systemFont(ofSize: 12))
                self.stockQtyLabel.attributedText = NSMutableAttributedString().attributedString("\(AppStrings.netQty): ", color: .lightGray, font: .systemFont(ofSize: 12)).attributedString("\(stockDetail.quantity)", color: .black, font: .systemFont(ofSize: 12))
                
                if (stockDetail.pnl ?? 0) < 0 {
                    self.stockPNLLabel.attributedText = NSMutableAttributedString().attributedString("\(AppStrings.pnl): ", color: .lightGray, font: .systemFont(ofSize: 12)).attributedString("-₹\((abs(stockDetail.pnl ?? 0).formattedWithCommas))", color: .red, font: .systemFont(ofSize: 12))
                }else {
                    self.stockPNLLabel.attributedText = NSMutableAttributedString().attributedString("\(AppStrings.pnl): ", color: .lightGray, font: .systemFont(ofSize: 12)).attributedString("₹\((stockDetail.pnl ?? 0).formattedWithCommas)", color: .green, font: .systemFont(ofSize: 12))
                }
                
            }
        }
    }
    
 
    
//    MARK: Init method
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .clear

        addLayouts()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    private func addLayouts() {
        
        self.contentView.addSubview(stockNameLabel)
        self.stockNameLabel.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 16.0).isActive = true
        self.stockNameLabel.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 12).isActive = true
        self.contentView.layoutIfNeeded()

        self.contentView.addSubview(stockLTPLabel)
        self.stockLTPLabel.centerYAnchor.constraint(equalTo: self.stockNameLabel.centerYAnchor).isActive = true
        self.stockLTPLabel.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -12).isActive = true
        self.contentView.layoutIfNeeded()

        self.contentView.addSubview(stockQtyLabel)
        self.stockQtyLabel.topAnchor.constraint(equalTo: self.stockNameLabel.bottomAnchor, constant: 16.0).isActive = true
        self.stockQtyLabel.leadingAnchor.constraint(equalTo: self.stockNameLabel.leadingAnchor).isActive = true
        self.stockQtyLabel.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -12).isActive = true
        self.contentView.layoutIfNeeded()

        self.contentView.addSubview(stockPNLLabel)
        self.stockPNLLabel.centerYAnchor.constraint(equalTo: self.stockQtyLabel.centerYAnchor).isActive = true
        self.stockPNLLabel.trailingAnchor.constraint(equalTo: self.stockLTPLabel.trailingAnchor).isActive = true
        self.contentView.layoutIfNeeded()
    }
    
    class func identifier() -> String {
        return  String(describing: self)
    }

}
