//
//  PNLFieldsTableViewCell.swift
//  UpStocks
//
//  Created by Mohit on 04/11/24.
//

import UIKit

class PNLFieldsTableViewCell: UITableViewCell {
    
    lazy var titleLable: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .boldSystemFont(ofSize: 14)
        label.textColor = .black.withAlphaComponent(0.6)
        return label
    }()
    
    lazy var valueLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var detail: HoldingTotalSumModel? {
        didSet {
            if let detail = self.detail {
                self.titleLable.setTextWithAsterisk(detail.title)
                if detail.value > 0 {
                    self.valueLabel.attributedText = NSMutableAttributedString().attributedString("₹\(detail.value.formattedWithCommas)", color: .black, font: .systemFont(ofSize: 12))
                }else {
                    self.valueLabel.attributedText = NSMutableAttributedString().attributedString("-₹\(((abs(detail.value).formattedWithCommas)))", color: .red, font: .systemFont(ofSize: 12))

                }
            }
        }
    }
    
    //    MARK: Init method
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .clear
        
        addLayouts()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    private func addLayouts() {
        self.contentView.addSubview(titleLable)
        self.titleLable.topAnchor.constraint(equalTo: self.contentView.topAnchor, constant: 6.0).isActive = true
        self.titleLable.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 16).isActive = true
        self.titleLable.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: -20.0).isActive = true
        self.contentView.layoutIfNeeded()
        
        self.contentView.addSubview(valueLabel)
        self.valueLabel.centerYAnchor.constraint(equalTo: self.titleLable.centerYAnchor).isActive = true
        self.valueLabel.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -16).isActive = true
        self.contentView.layoutIfNeeded()
    }
    
    class func identifier() -> String {
        return String(describing: self)
    }
    
}

